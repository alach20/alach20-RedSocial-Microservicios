 /*authenticate: verifica si el usuario y la contraseña coinciden */
 /* register: guarda un nuevo usuario en la base de datos*/


package com.redsocial.authservice.service;

import com.redsocial.authservice.model.User;
import com.redsocial.authservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public boolean authenticate(String username, String password) {
        Optional<User> user = userRepository.findByUsername(username);
        return user.isPresent() && user.get().getPassword().equals(password);
    }

    public User register(User user) {
        return userRepository.save(user);
    }

}
