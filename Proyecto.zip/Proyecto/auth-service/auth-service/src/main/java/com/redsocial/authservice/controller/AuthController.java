package com.redsocial.authservice.controller;

import com.redsocial.authservice.model.User;
import com.redsocial.authservice.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import com.redsocial.authservice.service.JwtUtil;


@RestController
@RequestMapping("/auth")

public class AuthController {
    @Autowired
    private AuthService authService;

    @Autowired
    private JwtUtil jwtUtil;


    @GetMapping("/login")
    public ResponseEntity<String> login(@RequestParam String username,
                                        @RequestParam String password) {

        boolean isAuthenticated = authService.authenticate(username, password);

        if (isAuthenticated) {
            String token = jwtUtil.generateToken(username);
            return ResponseEntity.ok("Bearer " + token); // Visualiza el token en el body
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales incorrectas");
        }
    }



    @PostMapping("/register")
    public User register(@RequestBody User user) {
        System.out.println("Usuario recibido:");
        System.out.println("  username: " + user.getUsername());
        System.out.println("  password: " + user.getPassword());
        System.out.println("  firstName: " + user.getFirstName());
        System.out.println("  lastName: " + user.getLastName());
        System.out.println("  alias: " + user.getAlias());
        System.out.println("  birthDate: " + user.getBirthDate());
        return authService.register(user);
    }
    @GetMapping("/secure")
    public String secureRoute() {
        return "✅ Acceso permitido con token válido";
    }


}