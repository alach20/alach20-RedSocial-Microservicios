# Red Social - Microservicios con Spring Boot y React

Este proyecto implementa una red social sencilla utilizando **arquitectura de microservicios**, con funcionalidades básicas como autenticación, creación de publicaciones, likes y visualización de perfiles.

---

## 🧩 Microservicios

### 1. `auth-service`
- **Responsable de la autenticación** mediante JWT
- Login de usuarios (`GET`)
- Generación y validación de tokens

### 2. `user-service`
- Gestión de perfiles de usuario
- Ver perfil de usuario (`GET`)
- Base de datos H2 persistente para pruebas
- Swagger para documentación REST

### 3. `post-service`
- Crear publicaciones (`POST`)
- Listar publicaciones (`GET`)
- Dar likes (`POST`)
- HTML simple para crear y visualizar publicaciones
- Swagger habilitado

---

## 💻 Frontend

- **React JS** y HTML
- Formularios para crear publicaciones y ver publicaciones con likes
- Comunicación con los microservicios usando `fetch` (REST API)

---

## 🛠️ Tecnologías utilizadas

- Java 17
- Spring Boot 3.4.5
- Spring Security
- Spring Data JPA
- H2 (modo archivo)
- React JS
- JWT (Json Web Token)
- Maven
- Swagger (`springdoc-openapi`)

---

## 🔧 Instalación

### 1. Clona el repositorio

```bash
git clone https://github.com/tu-usuario/red-social.git
cd red-social
```

### 2. Ejecutar microservicios

Cada servicio tiene su propio `pom.xml`. Puedes correrlos con Maven o desde tu IDE (Eclipse o IntelliJ):

```bash
cd user-service
mvn spring-boot:run
```

Repite el paso para `post-service` y `auth-service`.

### 3. Acceso a Swagger

Una vez los servicios estén en ejecución, accede a la documentación Swagger en:

- `http://localhost:8080/swagger-ui.html` (auth-service)
- `http://localhost:8081/swagger-ui.html` (post-service)
- `http://localhost:8082/swagger-ui.html` (user-service)

---

## 📂 Estructura de carpetas

```
red-social/
├── auth-service/          # Autenticación JWT
│   └── src/...
├── user-service/          # Gestión de perfiles de usuario
│   └── src/...
├── post-service/          # Publicaciones y likes
│   └── src/...
├── frontend-react/        # HTML y React para frontend
│   └── public/
│       ├── crear-publicacion.html
│       └── ver-publicaciones.html
└── README.md
```

End Points Disponibles

Se encuentran en la carpeta Proyecto\Postman

---

## 👨‍💻 Autor

Proyecto desarrollado por **Aida Lucia Ávila** como parte de una práctica de arquitectura de microservicios.

---