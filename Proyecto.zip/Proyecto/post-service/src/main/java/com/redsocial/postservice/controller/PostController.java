package com.redsocial.postservice.controller;

import com.redsocial.postservice.model.Post;
import com.redsocial.postservice.service.PostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;



@CrossOrigin(origins = "*") // Permite acceso desde HTML local
@RestController
@RequestMapping("/posts")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public List<Post> getAllPosts() {
        return postService.getAllPosts();
    }

    @PostMapping
    public ResponseEntity<Post> createPost(@RequestBody Post post) {
        post.setCreatedAt(LocalDateTime.now()); // Asignar timestamp
        Post saved = postService.createPost(post);
        return ResponseEntity.ok(saved);
    }
}
