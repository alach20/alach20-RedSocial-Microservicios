package com.redsocial.user_service.controller;

import com.redsocial.user_service.model.User;
import com.redsocial.user_service.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/{alias}")
    public ResponseEntity<User> getUserProfile(@PathVariable String alias) {
        return userService.getUserByAlias(alias)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}