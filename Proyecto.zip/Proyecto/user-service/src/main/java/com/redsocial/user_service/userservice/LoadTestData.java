package com.redsocial.user_service.userservice;

import com.redsocial.user_service.model.User;
import com.redsocial.user_service.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadTestData {

    @Bean
    public CommandLineRunner loadData(UserRepository userRepository) {
        return args -> {
            if (userRepository.findByAlias("jlopez").isEmpty()) {
                User user = User.builder()
                        .username("jlopez")
                        .password("1234")
                        .firstName("Juan")
                        .lastName("Lopez")
                        .alias("jlopez")
                        .birthDate("1990-01-01")
                        .build();
                userRepository.save(user);
            }
        };
    }
}